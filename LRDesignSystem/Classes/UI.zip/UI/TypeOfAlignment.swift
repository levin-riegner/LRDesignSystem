//
//  TypeOfAlignment.swift
//  GlobalCitizenComponents
//
//  Created by Pedro Manfredi on 25/09/2019.
//  Copyright © 2019 Pedro Manfredi. All rights reserved.
//

import Foundation
enum TypeOfAlignment: String {
    case left
    case center
    case right
}
